
<footer class="bg-dark text-white text-center py-3 mt-auto">
    <div class="container">
        <p>&copy; <?= date('Y') ?> AGSTATION. All rights reserved.</p>
        <p>
            <a href="../frontend/privacy-policy.php" class="text-white text-decoration-none">Privacy Policy</a> |
            <a href="../frontend/terms-of-service.php" class="text-white text-decoration-none">Terms of Service</a>
        </p>
    </div>
</footer>
<!-- Bootstrap JS (CDN) -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script src="/assets/js/script.js"></script>
</body>
</html>
